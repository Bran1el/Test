package practice;

public class square extends TwoDimensionalShape {
	private double y;
	private double x;
	
	public square (double x, double y){
		this.y = y;
		this.x = x;
	}
	
	
	public double gety(){
		return y;
	}
	public double getx(){
		return x;
	}
	
	
	
	
}
