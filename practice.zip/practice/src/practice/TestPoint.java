package practice;
import java.util.Scanner;

public class TestPoint {
public static void main(String[] args){
	Scanner scan = new Scanner (System.in);
	
	System.out.println("Enter point x: ");
	double xx = scan.nextDouble();
	
	System.out.println("Enter point y: ");
    double yy = scan.nextDouble();
    
    
	point one = new point(xx, yy);
	//String p = one.toString();
	System.out.printf("%s",one);
	scan.close();
}
}
