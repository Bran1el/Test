package practice;

public class TwoDimensionalShape extends shape {
	
	private String y;
	private String x;
	

	

}
