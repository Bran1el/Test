
package practice;

public class point {
	private double y;
	private double x;
	
	public point(double x, double y){
		this.x = x;
		this.y = y;
	}
	
	public double gety(){
		return y;
	}
	public double getx(){
		return x;
	}
	
@Override
public  String toString(){
	return  String.format("Point X: %f, %nPoint Y: %f", getx(), gety());
			
}
}
