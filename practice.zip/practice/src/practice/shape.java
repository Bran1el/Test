package practice;

public class shape extends point {
	

	
}
